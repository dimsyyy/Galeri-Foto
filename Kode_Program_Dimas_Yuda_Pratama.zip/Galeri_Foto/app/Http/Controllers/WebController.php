<?php

namespace App\Http\Controllers;

use App\Models\Album;
use App\Models\Foto;
use App\Models\Komentar;
use App\Models\Like;
use App\Models\User;
use Carbon\Carbon;
use Illuminate\Http\Request;


class WebController extends Controller
{
    public function index()
    {
        $foto = Foto::all();
        $user = User::all();

        return view('contents.home', compact('foto', 'user'));
    }
    //LOGIN
    public function login(Request $req)
    {
        $data = User::where('Username', $req->input('username'))->where('Password', $req->input('password'))->first();

        if ($data) {
            session()->put('user', $data);
            return redirect('/');
        } else {
            return redirect()->back()->with('err', 'Username atau password salah!');
        }
    }
    public function register(Request $req)
    {
        $data = new User;
        $data->NamaLengkap = $req->input('namalengkap');
        $data->Username = $req->input('username');
        $data->Password = $req->input('password');
        $data->Email = $req->input('email');
        $data->Alamat = $req->input('alamat');

        // dd($data);
        $data->save();
        return redirect('/log')->with('suc', 'Pendaftaran berhasil, silahkan masuk!');
    }

    //LOGOUT
    public function logout()
    {
        session()->flush();
        return redirect('/');
    }

    //BUAT ALBUM
    public function buatalbum()
    {
        if (session('user')) {
            return view('contents.createalbum');
        } else {
            return redirect('/');
        }
    }
    public function buatalbumAksi(Request $req)
    {
        $album = new Album;
        $album->NamaAlbum = $req->input('namaalbum');
        $album->Deskripsi = $req->input('desk');
        $album->TanggalDibuat = Carbon::now();
        $album->UserID = session('user')->UserID;

        // dd($album);
        $album->save();
        return redirect('lihatalbum')->with('suc', 'Album berhasil di buat');
    }
    public function lihatalbum()
    {
        if (session('user')) {
            $album = Album::where('UserID', session('user')->UserID)->orderBy('AlbumID', 'asc')->get();
            return view('contents.lihatalbum', compact('album'));
        } else {
            return redirect('/');
        }
    }
    public function lihatfotoalbum($AlbumID)
    {
        $foto = Foto::where('AlbumID', $AlbumID)->get();
        $album = Album::find($AlbumID);
        return view('contents.lihatfotoalbum', compact('foto', 'album'));
    }

    //FOTO
    public function unggahfoto()
    {
        $album = Album::where('UserID', session('user')->UserID)->get();
        return view('contents.unggahfoto', compact('album'));
    }
    public function unggahfotoAksi(Request $req)
    {
        if ($req->hasFile('gambar')) {
            $locate = $req->file('gambar')->store('public/images');

            $data = new Foto;
            $data->JudulFoto = $req->input('judul');
            $data->DeskripsiFoto = $req->input('deskripsi');
            $data->TanggalUnggah = Carbon::now();
            $data->LokasiFile = $locate;
            $data->AlbumID = $req->input('album');
            $data->UserID = session('user')->UserID;

            // dd($data);
            $data->save();
            return redirect('lihatfotoalbum/' . $req->input('album'));
        } else {
            return redirect()->back()->with('err', 'Foto gagal diunggah');
        }
    }
    public function lihatfoto($FotoID)
    {
        if (session('user')) {
            $foto = Foto::find($FotoID);
            $like = Like::all();
            $komen = Komentar::where('FotoID', $FotoID)->get();
            $user = User::find($foto->UserID);
            $user2 = User::all();
            return view('contents.lihatfoto', compact('foto', 'user', 'like', 'komen', 'user2'));
        } else{
            return redirect('/')->with('err', 'Kamu harus masuk terlebih dahulu untuk melihat foto');
        }
    }

    //LIKE DAN KOMEN
    public function like($FotoID)
    {
        $validasi = Like::where('FotoID', $FotoID)->where('UserID', session('user')->UserID)->first();
        if ($validasi) {
            $validasi->delete();
            return redirect()->back();
        } else {
            $like = new Like;
            $like->FotoID = $FotoID;
            $like->UserID = session('user')->UserID;
            $like->TanggalLike = Carbon::now();
            $like->save();
            return redirect()->back();
        }
    }
    public function komen(Request $req, $FotoID){
        $komen = new Komentar;
        $komen->FotoID = $FotoID;
        $komen->UserID = session('user')->UserID;
        $komen->IsiKomentar = $req->input('isi');
        $komen->TanggalKomentar = Carbon::now();

        $komen->save();
        return redirect()->back();
    }

    //HAPUS FOTO
    public function delete($FotoID){
        $foto = Foto::find($FotoID);
        // dd($foto);
        $foto->delete();
        return redirect()->back()->with('suc', 'Foto berhasil di hapus');
    }
}
