function Sidebar(){
    // console.log('button di klik')
    const sidebar = document.getElementById("Sidebar")

    if(sidebar.style.left == '0' || sidebar.style.left == ''){
        sidebar.style.left = "-250px"
    } else{
        sidebar.style.left = ""
    }
}