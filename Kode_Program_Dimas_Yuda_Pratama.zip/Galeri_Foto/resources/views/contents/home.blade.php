@extends('template.public')
@section('title', 'Home')
@section('konten')
    <div class="home">
        <h2>Galeri Foto</h2>
        <p>
            Selamat datang di website galeri foto, disini kamu bisa melihat, memberikan like, dan memberikan <br>
            komentar pada foto unggahan pengguna lain. Selamat bersenang - senang
        </p>
        <div class="formbottom">
            <p class="err">{{ session('err') }}</p>
            <p class="suc">{{ session('suc') }}</p>
        </div>
    </div>
    <div class="image">
        <h2>Gambar Terbaru</h2>
        <div class="wrap-foto">
            @foreach ($foto as $fto)
                <div class="fotonya">
                    <a href="/lihatfoto/{{$fto->FotoID}}">
                    <img src="{{ Storage::url($fto->LokasiFile) }}" alt="gambar">
                    <p><i class="fa-solid fa-circle-user"></i>
                        @if ($tes = $user->where('UserID', $fto->UserID)->first())
                            {{ $tes->NamaLengkap }}
                        @endif
                    </p>
                </a>
                </div>
            @endforeach
        </div>
    </div>
@endsection
