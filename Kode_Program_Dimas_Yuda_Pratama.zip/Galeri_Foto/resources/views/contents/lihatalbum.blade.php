@extends('template.public')
@section('title', 'Album Kamu')
@section('konten')

    <div class="center">
        <div class="container-alb">
            <div class="add-alb">
                <a href="{{ url('/buatalbum') }}"><i class="fa-solid fa-plus" style="font-size: 25px"></i>&emsp14;<p>Tambah Album</p></a>
            </div>
            <div class="alb-grid">
                @foreach ($album as $alb)
                    <a href="lihatfotoalbum/{{ $alb->AlbumID }}" style="text-decoration: none;color: #222;margin: 5px 15px;">
                        <div class="album">
                            <div class="nama-alb">
                                <i class="fa-regular fa-images"></i>&emsp14;<p><b>{{ $alb->NamaAlbum }}</b></p>
                            </div>
                            <div class="desk">{{ $alb->Deskripsi }}</div>
                        </div>
                    </a>
                @endforeach
            </div>
        </div>
    </div>

@endsection
