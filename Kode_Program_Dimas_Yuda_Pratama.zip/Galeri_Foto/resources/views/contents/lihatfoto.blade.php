@extends('template.public')
@section('title', $user->Username)
@section('konten')

    <div class="see-img">
        <div class="fotonya">
            <img src="{{ Storage::url($foto->LokasiFile) }}" alt="...">
        </div>
        <div class="desk-img">
            <table>
                <tr>
                    <td>Judul Foto</td>
                    <td>:</td>
                    <td> {{ $foto->JudulFoto }}</td>
                </tr> 
                <tr>
                    <td>Deskripsi Foto</td>
                    <td>:</td>
                    <td>{{ $foto->DeskripsiFoto }}</td>
                </tr>
            </table>
        </div>
        <div class="like-com">
            <div class="user-prof"><i class="fa-solid fa-circle-user"></i> {{ $user->NamaLengkap }}</div>
            <div class="btnlk">
                <div class="like">

                    @if ($like->where('UserID', session('user')->UserID)->where('FotoID', $foto->FotoID)->first())
                        <a href="/berilike/{{ $foto->FotoID }}">
                            <i class="fa-solid fa-thumbs-up" style="font-size: 20px"></i>
                        </a>
                        {{ $like->where('FotoID', $foto->FotoID)->count() }}
                    @else
                        <a href="/berilike/{{ $foto->FotoID }}">
                            <i class="fa-regular fa-thumbs-up" style="font-size: 20px"></i>
                        </a>
                        {{ $like->where('FotoID', $foto->FotoID)->count() }}
                    @endif
                </div>
                <div class="komentar">
                    <i class="fa-regular fa-comment" style="font-size: 20px"></i>
                    {{ $komen->count() }}
                </div>
            </div>
        </div>
        <hr style="width: 100%; color: black; height: 1px;background-color: black;">
        @if ($komen->isEmpty())
            <div class="kom">
                Belum ada komentar, jadilah pertama yang menanggapi!
            </div>
        @else
        
            @foreach ($komen as $kom)
                <div class="kom">
                    <div class="kom-left">
                        <div class="user-com"><i class="fa-solid fa-circle-user"></i>
                            @if ($namanya = $user2->where('UserID', $kom->UserID)->first())
                                {{ $namanya->NamaLengkap }}
                            @endif
                        </div>
                        <div class="isi-com">{{ $kom->IsiKomentar }}</div>
                    </div>
                    <div class="tgl-kom">
                        {{ $kom->TanggalKomentar }}
                    </div>
                </div>
            @endforeach
        @endif
        <div class="create-kom">
            <form action="/berikomen/{{$foto->FotoID}}" method="post">
                @csrf
                <input type="text" name="isi" placeholder="Masukkan komentar kamu..." required class="isi-komen">
                <button class="no-btn"><i class="fa-solid fa-paper-plane"></i></button>
            </form>
        </div>
    </div>

@endsection
