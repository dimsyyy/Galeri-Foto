@extends('template.public')
@section('title', 'Album Kamu')
@section('konten')

    <h2 style="margin: 10px; font-family: 'Nunito sans'; margin-top: 10%; text-align: center;">Album {{ $album->NamaAlbum }}
        <br>
    </h2>
    <div class="formbottom">
        <p class="err">{{ session('err') }}</p>
        <p class="suc">{{ session('suc') }}</p>
    </div>
    <div class="wrap-foto" style="margin-top: 1]%;">
        @foreach ($foto as $fto)
            <div class="fotonya">
                <a href="/lihatfoto/{{ $fto->FotoID }}">
                    <img src="{{ Storage::url($fto->LokasiFile) }}" alt="gambar">
                </a>
                <div class="delete">
                    <a href="/delete/{{ $fto->FotoID }}" style="display:flex; align-items:center;margin-top: -16px;"><i
                            class="fa-solid fa-trash" style="font-size: 15px; color: red;"></i>
                        <p>&emsp14;Hapus</p>
                    </a>
                </div>
            </div>
        @endforeach
    </div>

@endsection
