@extends('template.public')
@section('title', 'Masuk')
@section('konten')

<div class="contain-log">
    <div class="icon">
        <img src="{{asset('img/user.png')}}" alt="user">
    </div>
    <div class="formbottom">
        <p class="err">{{ session('err') }}</p>
        <p class="suc">{{ session('suc') }}</p>
    </div>

    
    <form action="/logAksi" method="POST">
        @csrf
        <table cellspacing="5">
            <tr>
                <td>Username :</td>
            </tr>
            <tr>
                <td><input type="text" name="username" placeholder="Masukkan username" required autofocus></td>
            </tr>
            <tr>
                <td>Password :</td>
            </tr>
            <tr>
                <td><input type="password" name="password" placeholder="Masukkan password" required></td>
            </tr>
        </table>
        <div class="formbottom">
            <p>Belum punya akun, <a href="/registrasi">Daftar</a> sekarang</p>
            <center><button>Masuk</button></center>
        </div>
    </form>
</div>
    
@endsection