@extends('template.public')
@section('title', 'Daftar')
@section('konten')

    <div class="wrap-reg">
        <div class="icon">
            <img src="{{asset('img/user.png')}}"></img>
        </div>
        <form action="regAksi" method="post">
            @csrf
            <table cellspacing="5">
                <center>
                    <tr>
                        <td colspan="2">Nama Lengkap :</td>
                    </tr>
                    <tr>
                        <td colspan="2"><input type="text" name="namalengkap" required class="fullreg"
                                placeholder="Masukkan Nama Lengkap" autofocus></td>
                    </tr>
                    <tr>
                        <td>Username :</td>
                        <td>Password :</td>
                    </tr>
                    <tr>
                        <td><input type="text" name="username" required placeholder="Masukkan Username" class="setreg">
                        </td>
                        <td><input type="password" name="password" required placeholder="Masukkan Password" class="setreg">
                        </td>
                    </tr>
                    <tr>
                        <td colspan="2">Email :</td>
                    </tr>
                    <tr>
                        <td colspan="2"><input type="email" name="email" required class="fullreg"
                                placeholder="Masukkan Email"></td>
                    </tr>
                    <tr>
                        <td colspan="2">Alamat :</td>
                    </tr>
                    <tr>
                        <td colspan="2">
                            <textarea name="alamat">Masukkan Alamat</textarea>
                        </td>
                    </tr>
                </center>
            </table>
            <div class="formbottom">
                <p>Sudah punya akun, <a href="/log">masuk</a> sekarang</p>
                <center><button>Daftar</button></center>
            </div>
        </form>
    </div>

@endsection
