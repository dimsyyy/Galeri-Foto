@extends('template.public')
@section('title', 'Unggah Foto')
@section('konten')

<div class="contain-log">
    <div class="formbottom">
        <p>{{ session('suc') }}</p>
        <p>{{ session('err') }}</p>
    </div>
    <table class="upload">
        <form action="unggahfotoAksi" method="POST" enctype="multipart/form-data">
            @csrf
            <tr>
                <td>Judul Foto :</td>
            </tr>
            <tr>
                <td><input type="text" name="judul" placeholder="Masukkan judul foto" class="judulfoto" autofocus></td>
            </tr>
            <tr>
                <td>Deskripsi Foto :</td>
            </tr>
            <tr>
                <td>
                    <textarea name="deskripsi" class="desk-fto">Masukkan deskripsi foto</textarea>
                </td>
            </tr>
            <tr>
                <td>Pilih Foto :</td>
            </tr>
            <tr>
                <td><input type="file" accept=".png, .jpeg, .jpg, .webp, .heic" name="gambar"></td>
            </tr>
            <tr>
                <td>Pilih Album :</td>
            </tr>
            <tr>
                <td>
                    @if ($album->isEmpty())
                        <p style="font-size: 15px">Kamu belum punya album,<a href="{{ url('/buatalbum') }}" style="text-decoration: none; color: blue;"> Buat sekarang!</a></p>
                    @else
                        <select name="album" class="opsi">
                            @foreach ($album as $alb)
                                <option value="{{ $alb->AlbumID }}">{{ $alb->NamaAlbum }}</option>
                            @endforeach
                        </select>
                    @endif
                </td>
            </tr>
            <tr>
                <td><button class="unggah">Unggah</button></td>
            </tr>
        </form>
    </table>
</div>
    
@endsection