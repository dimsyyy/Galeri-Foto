<div class="navbar">
    <div class="nav-left">
        @if (session('user') == !null)
            <button class="no-btn" onclick="Sidebar()"><i class="fa-solid fa-bars"></button></i>
        @endif
        <h2 style="font-family: 'Lovelo';">Galeri Foto</h2>
    </div>
    <div class="nav-right">
        <div class="nav-btn">
            @if (!request()->is('/'))
                <a href="/"><button class="btn-index">Home</button></a>
            @endif
            @if (session('user') == null)

                @if (!request()->is('registrasi', '/'))
                    <a href="/registrasi"><button> Daftar </button></a>
                @endif
                @if (!request()->is('log'))
                    <a href="/log"><button> Masuk </button></a>
                @endif
            @else
                <a href="/logout"><button class="btn-index"> Keluar </button></a>
            @endif
        </div>
    </div>
</div>
@if (session('user') == !null)
    <div class="sidebar" id="Sidebar">
        <ul>
            <li class="name">
                <i class="fa-solid fa-circle-user"></i> {{ session('user')->NamaLengkap }}
            </li>
            <li>
                <hr>
            </li>
            <li class="{{ request()->is('buatalbum') ? 'active' : '' }}">
                <a href="{{ url('/buatalbum') }}">
                    <i class="fas fa-folder-plus"></i> Buat Album
                </a>
            </li>
            <li>
                <hr>
            </li>
            <li class="{{ request()->is('unggahfoto') ? 'active' : '' }}">
                <a href="{{ url('/unggahfoto') }}">
                    <i class="fas fa-image"></i> Unggah Foto
                </a>
            </li>
            <li>
                <hr>
            </li>
            <li class="{{ request()->is('lihatalbum','lihatfotoalbum/*') ? 'active' : '' }}">
                <a href="{{ url('/lihatalbum') }}">
                    <i class="fas fa-folder-open"></i> Lihat Album
                </a>
            </li>
            <li>
                <hr>
            </li>
        </ul>
    </div>
@endif
