<?php

use App\Http\Controllers\WebController;
use Illuminate\Support\Facades\Route;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider and all of them will
| be assigned to the "web" middleware group. Make something great!
|
*/

//INDEX
Route::get('/',[WebController::class, 'index']);


//LOGIN DAN REGISTRASI
Route::get('/log', function () {
    return view('contents.login');
});
Route::get('/registrasi', function () {
    return view('contents.regist');
});
Route::post('/logAksi',[WebController::class, 'login']);
Route::post('/regAksi',[WebController::class, 'register']);

//LOGOUT
Route::get('/logout',[WebController::class, 'logout']);


//ROUTES ALBUM
Route::get('/buatalbum',[WebController::class, 'buatalbum']);
Route::post('/buatalbumAksi',[WebController::class, 'buatalbumAksi']);
Route::get('/lihatalbum',[WebController::class, 'lihatalbum']);
Route::get('lihatfotoalbum/{AlbumID}',[WebController::class, 'lihatfotoalbum']);

//FOTO
Route::get('/unggahfoto',[WebController::class, 'unggahfoto']);
Route::get('/lihatfoto/{FotoID}',[WebController::class, 'lihatfoto']);
Route::post('/unggahfotoAksi',[WebController::class, 'unggahfotoAksi']);

//LIKE KOMEN
Route::get('/berilike/{FotoID}',[WebController::class, 'like']);
Route::post('/berikomen/{FotoID}',[WebController::class, 'komen']);

//HAPUS FOTO
Route::get('/delete/{FotoID}',[WebController::class, 'delete']);
