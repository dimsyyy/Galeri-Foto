<div class="navbar">
    <div class="nav-left">
        <?php if(session('user') == !null): ?>
            <button class="no-btn" onclick="Sidebar()"><i class="fa-solid fa-bars"></button></i>
        <?php endif; ?>
        <h2 style="font-family: 'Lovelo';">Galeri Foto</h2>
    </div>
    <div class="nav-right">
        <div class="nav-btn">
            <?php if(!request()->is('/')): ?>
                <a href="/"><button class="btn-index">Home</button></a>
            <?php endif; ?>
            <?php if(session('user') == null): ?>

                <?php if(!request()->is('registrasi', '/')): ?>
                    <a href="/registrasi"><button> Daftar </button></a>
                <?php endif; ?>
                <?php if(!request()->is('log')): ?>
                    <a href="/log"><button> Masuk </button></a>
                <?php endif; ?>
            <?php else: ?>
                <a href="/logout"><button class="btn-index"> Keluar </button></a>
            <?php endif; ?>
        </div>
    </div>
</div>
<?php if(session('user') == !null): ?>
    <div class="sidebar" id="Sidebar">
        <ul>
            <li class="name">
                <i class="fa-solid fa-circle-user"></i> <?php echo e(session('user')->NamaLengkap); ?>

            </li>
            <li>
                <hr>
            </li>
            <li class="<?php echo e(request()->is('buatalbum') ? 'active' : ''); ?>">
                <a href="<?php echo e(url('/buatalbum')); ?>">
                    <i class="fas fa-folder-plus"></i> Buat Album
                </a>
            </li>
            <li>
                <hr>
            </li>
            <li class="<?php echo e(request()->is('unggahfoto') ? 'active' : ''); ?>">
                <a href="<?php echo e(url('/unggahfoto')); ?>">
                    <i class="fas fa-image"></i> Unggah Foto
                </a>
            </li>
            <li>
                <hr>
            </li>
            <li class="<?php echo e(request()->is('lihatalbum','lihatfotoalbum/*') ? 'active' : ''); ?>">
                <a href="<?php echo e(url('/lihatalbum')); ?>">
                    <i class="fas fa-folder-open"></i> Lihat Album
                </a>
            </li>
            <li>
                <hr>
            </li>
        </ul>
    </div>
<?php endif; ?>
<?php /**PATH C:\Users\USER\Galeri_Foto\resources\views/header/nav.blade.php ENDPATH**/ ?>