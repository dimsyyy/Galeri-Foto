
<?php $__env->startSection('title', 'Album Kamu'); ?>
<?php $__env->startSection('konten'); ?>

    <div class="center">
        <div class="container-alb">
            <div class="add-alb">
                <a href="<?php echo e(url('/buatalbum')); ?>"><i class="fa-solid fa-plus" style="font-size: 25px"></i>&emsp14;<p>Tambah Album</p></a>
            </div>
            <div class="alb-grid">
                <?php $__currentLoopData = $album; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $alb): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <a href="lihatfotoalbum/<?php echo e($alb->AlbumID); ?>" style="text-decoration: none;color: #222;margin: 5px 15px;">
                        <div class="album">
                            <div class="nama-alb">
                                <i class="fa-regular fa-images"></i>&emsp14;<p><b><?php echo e($alb->NamaAlbum); ?></b></p>
                            </div>
                            <div class="desk"><?php echo e($alb->Deskripsi); ?></div>
                        </div>
                    </a>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        </div>
    </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('template.public', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\USER\Galeri_Foto\resources\views/contents/lihatalbum.blade.php ENDPATH**/ ?>