<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Galeri | <?php echo $__env->yieldContent('title'); ?></title>
    <link rel="shortcut icon" href="<?php echo e(asset('img/icon,png.png')); ?>" type="image/x-icon">
    <link rel="stylesheet" href="<?php echo e(asset('style/style.css')); ?>">
</head>
<body>
    <?php echo $__env->make('header.nav', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <?php echo $__env->yieldContent('konten'); ?>

    <script src="https://kit.fontawesome.com/29c53c391a.js" crossorigin="anonymous"></script>
    <script src="<?php echo e(asset('script/main.js')); ?>"></script>
</body>
</html><?php /**PATH C:\Users\USER\Galeri_Foto\resources\views/template/public.blade.php ENDPATH**/ ?>