
<?php $__env->startSection('title', 'Album Kamu'); ?>
<?php $__env->startSection('konten'); ?>

    <h2 style="margin: 10px; font-family: 'Nunito sans'; margin-top: 10%; text-align: center;">Album <?php echo e($album->NamaAlbum); ?>

        <br>
    </h2>
    <div class="formbottom">
        <p class="err"><?php echo e(session('err')); ?></p>
        <p class="suc"><?php echo e(session('suc')); ?></p>
    </div>
    <div class="wrap-foto" style="margin-top: 1]%;">
        <?php $__currentLoopData = $foto; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $fto): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="fotonya">
                <a href="/lihatfoto/<?php echo e($fto->FotoID); ?>">
                    <img src="<?php echo e(Storage::url($fto->LokasiFile)); ?>" alt="gambar">
                </a>
                <div class="delete">
                    <a href="/delete/<?php echo e($fto->FotoID); ?>" style="display:flex; align-items:center;margin-top: -16px;"><i
                            class="fa-solid fa-trash" style="font-size: 15px; color: red;"></i>
                        <p>&emsp14;Hapus</p>
                    </a>
                </div>
            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('template.public', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\USER\Galeri_Foto\resources\views/contents/lihatfotoalbum.blade.php ENDPATH**/ ?>