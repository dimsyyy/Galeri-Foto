
<?php $__env->startSection('title', $user->Username); ?>
<?php $__env->startSection('konten'); ?>

    <div class="see-img">
        <div class="fotonya">
            <img src="<?php echo e(Storage::url($foto->LokasiFile)); ?>" alt="...">
        </div>
        <div class="desk-img">
            <table>
                <tr>
                    <td>Judul Foto</td>
                    <td>:</td>
                    <td> <?php echo e($foto->JudulFoto); ?></td>
                </tr> 
                <tr>
                    <td>Deskripsi Foto</td>
                    <td>:</td>
                    <td><?php echo e($foto->DeskripsiFoto); ?></td>
                </tr>
            </table>
        </div>
        <div class="like-com">
            <div class="user-prof"><i class="fa-solid fa-circle-user"></i> <?php echo e($user->NamaLengkap); ?></div>
            <div class="btnlk">
                <div class="like">

                    <?php if($like->where('UserID', session('user')->UserID)->where('FotoID', $foto->FotoID)->first()): ?>
                        <a href="/berilike/<?php echo e($foto->FotoID); ?>">
                            <i class="fa-solid fa-thumbs-up" style="font-size: 20px"></i>
                        </a>
                        <?php echo e($like->where('FotoID', $foto->FotoID)->count()); ?>

                    <?php else: ?>
                        <a href="/berilike/<?php echo e($foto->FotoID); ?>">
                            <i class="fa-regular fa-thumbs-up" style="font-size: 20px"></i>
                        </a>
                        <?php echo e($like->where('FotoID', $foto->FotoID)->count()); ?>

                    <?php endif; ?>
                </div>
                <div class="komentar">
                    <i class="fa-regular fa-comment" style="font-size: 20px"></i>
                    <?php echo e($komen->count()); ?>

                </div>
            </div>
        </div>
        <hr style="width: 100%; color: black; height: 1px;background-color: black;">
        <?php if($komen->isEmpty()): ?>
            <div class="kom">
                Belum ada komentar, jadilah pertama yang menanggapi!
            </div>
        <?php else: ?>
        
            <?php $__currentLoopData = $komen; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $kom): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="kom">
                    <div class="kom-left">
                        <div class="user-com"><i class="fa-solid fa-circle-user"></i>
                            <?php if($namanya = $user2->where('UserID', $kom->UserID)->first()): ?>
                                <?php echo e($namanya->NamaLengkap); ?>

                            <?php endif; ?>
                        </div>
                        <div class="isi-com"><?php echo e($kom->IsiKomentar); ?></div>
                    </div>
                    <div class="tgl-kom">
                        <?php echo e($kom->TanggalKomentar); ?>

                    </div>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <?php endif; ?>
        <div class="create-kom">
            <form action="/berikomen/<?php echo e($foto->FotoID); ?>" method="post">
                <?php echo csrf_field(); ?>
                <input type="text" name="isi" placeholder="Masukkan komentar kamu..." required class="isi-komen">
                <button class="no-btn"><i class="fa-solid fa-paper-plane"></i></button>
            </form>
        </div>
    </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('template.public', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\USER\Galeri_Foto\resources\views/contents/lihatfoto.blade.php ENDPATH**/ ?>