
<?php $__env->startSection('title', 'Buat Album'); ?>
<?php $__env->startSection('konten'); ?>

    <div class="contain-log">
        <div class="text-alb">Buat Album</div>
        <form action="/buatalbumAksi" method="POST">
            <?php echo csrf_field(); ?>
            <table cellspacing="5">
                <tr>
                    <td>Nama Album :</td>
                </tr>
                <tr>
                    <td><input type="text" name="namaalbum" placeholder="Masukkan nama album" required autofocus></td>
                </tr>
                <tr>
                    <td>Deskripsi :</td>
                </tr>
                <tr>
                    <td><textarea name="desk" class="desk-alb">Masukkan Deskripsi (Opsional)</textarea></td>
                </tr>
            </table>
            <div class="formbottom">
                <center><button>Buat</button></center>
            </div>
        </form>
    </div>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('template.public', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\USER\Galeri_Foto\resources\views/contents/createalbum.blade.php ENDPATH**/ ?>