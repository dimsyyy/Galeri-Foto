
<?php $__env->startSection('title', 'Masuk'); ?>
<?php $__env->startSection('konten'); ?>

<div class="contain-log">
    <div class="icon">
        <img src="<?php echo e(asset('img/user.png')); ?>" alt="user">
    </div>
    <div class="formbottom">
        <p class="err"><?php echo e(session('err')); ?></p>
        <p class="suc"><?php echo e(session('suc')); ?></p>
    </div>

    
    <form action="/logAksi" method="POST">
        <?php echo csrf_field(); ?>
        <table cellspacing="5">
            <tr>
                <td>Username :</td>
            </tr>
            <tr>
                <td><input type="text" name="username" placeholder="Masukkan username" required autofocus></td>
            </tr>
            <tr>
                <td>Password :</td>
            </tr>
            <tr>
                <td><input type="password" name="password" placeholder="Masukkan password" required></td>
            </tr>
        </table>
        <div class="formbottom">
            <p>Belum punya akun, <a href="/registrasi">Daftar</a> sekarang</p>
            <center><button>Masuk</button></center>
        </div>
    </form>
</div>
    
<?php $__env->stopSection(); ?>
<?php echo $__env->make('template.public', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\USER\Galeri_Foto\resources\views/contents/login.blade.php ENDPATH**/ ?>