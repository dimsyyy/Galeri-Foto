
<?php $__env->startSection('title', 'Daftar'); ?>
<?php $__env->startSection('konten'); ?>

    <div class="wrap-reg">
        <div class="icon">
            <img src="<?php echo e(asset('img/user.png')); ?>"></img>
        </div>
        <form action="regAksi" method="post">
            <?php echo csrf_field(); ?>
            <table cellspacing="5">
                <center>
                    <tr>
                        <td colspan="2">Nama Lengkap :</td>
                    </tr>
                    <tr>
                        <td colspan="2"><input type="text" name="namalengkap" required class="fullreg"
                                placeholder="Masukkan Nama Lengkap" autofocus></td>
                    </tr>
                    <tr>
                        <td>Username :</td>
                        <td>Password :</td>
                    </tr>
                    <tr>
                        <td><input type="text" name="username" required placeholder="Masukkan Username" class="setreg">
                        </td>
                        <td><input type="password" name="password" required placeholder="Masukkan Password" class="setreg">
                        </td>
                    </tr>
                    <tr>
                        <td colspan="2">Email :</td>
                    </tr>
                    <tr>
                        <td colspan="2"><input type="email" name="email" required class="fullreg"
                                placeholder="Masukkan Email"></td>
                    </tr>
                    <tr>
                        <td colspan="2">Alamat :</td>
                    </tr>
                    <tr>
                        <td colspan="2">
                            <textarea name="alamat">Masukkan Alamat</textarea>
                        </td>
                    </tr>
                </center>
            </table>
            <div class="formbottom">
                <p>Sudah punya akun, <a href="/log">masuk</a> sekarang</p>
                <center><button>Daftar</button></center>
            </div>
        </form>
    </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('template.public', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\USER\Galeri_Foto\resources\views/contents/regist.blade.php ENDPATH**/ ?>