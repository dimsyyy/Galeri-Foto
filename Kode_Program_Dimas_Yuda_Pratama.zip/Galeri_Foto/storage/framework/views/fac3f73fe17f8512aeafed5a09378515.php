
<?php $__env->startSection('title', 'Home'); ?>
<?php $__env->startSection('konten'); ?>
    <div class="home">
        <h2>Galeri Foto</h2>
        <p>
            Selamat datang di website galeri foto, disini kamu bisa melihat, memberikan like, dan memberikan <br>
            komentar pada foto unggahan pengguna lain. Selamat bersenang - senang
        </p>
        <div class="formbottom">
            <p class="err"><?php echo e(session('err')); ?></p>
            <p class="suc"><?php echo e(session('suc')); ?></p>
        </div>
    </div>
    <div class="image">
        <h2>Gambar Terbaru</h2>
        <div class="wrap-foto">
            <?php $__currentLoopData = $foto; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $fto): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="fotonya">
                    <a href="/lihatfoto/<?php echo e($fto->FotoID); ?>">
                    <img src="<?php echo e(Storage::url($fto->LokasiFile)); ?>" alt="gambar">
                    <p><i class="fa-solid fa-circle-user"></i>
                        <?php if($tes = $user->where('UserID', $fto->UserID)->first()): ?>
                            <?php echo e($tes->NamaLengkap); ?>

                        <?php endif; ?>
                    </p>
                </a>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('template.public', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\USER\Galeri_Foto\resources\views/contents/home.blade.php ENDPATH**/ ?>