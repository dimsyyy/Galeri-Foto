
<?php $__env->startSection('title', 'Unggah Foto'); ?>
<?php $__env->startSection('konten'); ?>

<div class="contain-log">
    <div class="formbottom">
        <p><?php echo e(session('suc')); ?></p>
        <p><?php echo e(session('err')); ?></p>
    </div>
    <table class="upload">
        <form action="unggahfotoAksi" method="POST" enctype="multipart/form-data">
            <?php echo csrf_field(); ?>
            <tr>
                <td>Judul Foto :</td>
            </tr>
            <tr>
                <td><input type="text" name="judul" placeholder="Masukkan judul foto" class="judulfoto" autofocus></td>
            </tr>
            <tr>
                <td>Deskripsi Foto :</td>
            </tr>
            <tr>
                <td>
                    <textarea name="deskripsi" class="desk-fto">Masukkan deskripsi foto</textarea>
                </td>
            </tr>
            <tr>
                <td>Pilih Foto :</td>
            </tr>
            <tr>
                <td><input type="file" accept=".png, .jpeg, .jpg, .webp, .heic" name="gambar"></td>
            </tr>
            <tr>
                <td>Pilih Album :</td>
            </tr>
            <tr>
                <td>
                    <?php if($album->isEmpty()): ?>
                        <p style="font-size: 15px">Kamu belum punya album,<a href="<?php echo e(url('/buatalbum')); ?>" style="text-decoration: none; color: blue;"> Buat sekarang!</a></p>
                    <?php else: ?>
                        <select name="album" class="opsi">
                            <?php $__currentLoopData = $album; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $alb): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($alb->AlbumID); ?>"><?php echo e($alb->NamaAlbum); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    <?php endif; ?>
                </td>
            </tr>
            <tr>
                <td><button class="unggah">Unggah</button></td>
            </tr>
        </form>
    </table>
</div>
    
<?php $__env->stopSection(); ?>
<?php echo $__env->make('template.public', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\USER\Galeri_Foto\resources\views/contents/unggahfoto.blade.php ENDPATH**/ ?>